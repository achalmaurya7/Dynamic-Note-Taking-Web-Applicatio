// script.js
document.addEventListener('DOMContentLoaded', function() {
    const noteInput = document.getElementById('noteInput');
    const notesList = document.getElementById('notesList');
    const addNoteBtn = document.getElementById('addNoteBtn');

    // Load notes from local storage
    const savedNotes = JSON.parse(localStorage.getItem('notes')) || [];
    savedNotes.forEach(note => addNoteToList(note));

    addNoteBtn.addEventListener('click', function() {
        const noteText = noteInput.value.trim();
        if (noteText !== '') {
            addNoteToList(noteText);
            saveNoteToLocalStorage(noteText);
            noteInput.value = '';
        } else {
            alert('Please enter a note.');
        }
    });

    function addNoteToList(noteText) {
        const listItem = document.createElement('li');

        const noteSpan = document.createElement('span');
        noteSpan.className = 'note-text';
        noteSpan.textContent = noteText;

        const editBtn = document.createElement('button');
        editBtn.className = 'edit-btn';
        editBtn.textContent = 'Edit';
        editBtn.addEventListener('click', function() {
            editNoteInList(listItem, noteSpan);
        });

        const deleteBtn = document.createElement('button');
        deleteBtn.className = 'delete-btn';
        deleteBtn.textContent = 'Delete';
        deleteBtn.addEventListener('click', function() {
            deleteNoteFromList(listItem, noteText);
        });

        listItem.appendChild(noteSpan);
        listItem.appendChild(editBtn);
        listItem.appendChild(deleteBtn);
        notesList.appendChild(listItem);
    }

    function editNoteInList(listItem, noteSpan) {
        const newNoteText = prompt('Edit your note:', noteSpan.textContent);
        if (newNoteText !== null) {
            const oldNoteText = noteSpan.textContent;
            noteSpan.textContent = newNoteText;
            updateNoteInLocalStorage(oldNoteText, newNoteText);
        }
    }

    function deleteNoteFromList(listItem, noteText) {
        listItem.remove();
        deleteNoteFromLocalStorage(noteText);
    }

    function saveNoteToLocalStorage(noteText) {
        const notes = JSON.parse(localStorage.getItem('notes')) || [];
        notes.push(noteText);
        localStorage.setItem('notes', JSON.stringify(notes));
    }

    function updateNoteInLocalStorage(oldNoteText, newNoteText) {
        const notes = JSON.parse(localStorage.getItem('notes')) || [];
        const noteIndex = notes.indexOf(oldNoteText);
        if (noteIndex !== -1) {
            notes[noteIndex] = newNoteText;
            localStorage.setItem('notes', JSON.stringify(notes));
        }
    }

    function deleteNoteFromLocalStorage(noteText) {
        const notes = JSON.parse(localStorage.getItem('notes')) || [];
        const updatedNotes = notes.filter(note => note !== noteText);
        localStorage.setItem('notes', JSON.stringify(updatedNotes));
    }
});
